//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class FileToStr {
    private static final int EOF = -1;
    private static final String DELIMITEURS_LIGNES = "\n\r";
    private static final String DELIMITEURS_DONNEES = ";\n\r\t\f";
    private static final String DELIMITEURS_MOTS = " .,;:-+*<>%/='\"()[]{}|!?\n\r\t\f0123456789";

    private FileToStr() {
    }

    private static String read(String fileName) throws Exception {
        BufferedInputStream in = new BufferedInputStream(new FileInputStream(fileName));
        StringBuilder b = new StringBuilder(in.available());

        for(int c = in.read(); c != -1; c = in.read()) {
            b.append((char)c);
        }

        in.close();
        return b.toString();
    }

    public static String[] lireCsv(String fileName) throws Exception{
        String str = read(fileName);
        new ArrayList();
        StringTokenizer sT = new StringTokenizer(str, "\n\r");
        String[] data = new String[sT.countTokens()];

        for(int cpt = 0; sT.hasMoreTokens(); ++cpt) {
            data[cpt] = sT.nextToken();
        }

        return data;
    }
}
